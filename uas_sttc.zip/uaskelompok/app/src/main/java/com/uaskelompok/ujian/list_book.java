package com.uaskelompok.ujian;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.uaskelompok.R;

public class list_book extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_book);
    }
}